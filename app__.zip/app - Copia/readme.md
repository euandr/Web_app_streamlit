## Instruções para Configurar o Projeto

1. Clone o repositório
    ```sh
    git clone https://github.com/euandr/web_app_streamlit.git
    ```

2. Instale as dependências:
    ```sh
    pip install -r requirements.txt
    ```

3. Execute a aplicação:
    ```sh
    streamlit run Login.py
    ```
